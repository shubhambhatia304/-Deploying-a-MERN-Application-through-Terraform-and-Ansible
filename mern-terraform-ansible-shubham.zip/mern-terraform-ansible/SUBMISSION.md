# Assignment Submission

**Assignment:** Deploying a MERN Application through Terraform and Ansible
**Name:** shubham Bhardwaj
**Application deployed:** https://github.com/UnpredictablePrashant/TravelMemory

**Repository link:** https://github.com/shubhambhardwaj/mern-terraform-ansible-shubham

**Live application URL:** http://13.206.15.238

## Contents
- `terraform/` — VPC, public and private subnets, Internet Gateway, NAT Gateway, route
  tables, two EC2 instances, security groups, IAM role and instance profile, outputs.
- `ansible/` — roles for base configuration, MongoDB, Node.js/Nginx/PM2, application
  deployment and security hardening; `site.yml` runs the full provisioning.
- `README.md` — detailed implementation report and component interaction diagram.
- `docs/screenshots/` — evidence of the working MERN application.
